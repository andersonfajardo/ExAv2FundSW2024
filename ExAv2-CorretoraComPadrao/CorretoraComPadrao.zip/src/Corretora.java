class Corretora {

    public void comprar(Conta conta, double quantidade) {
        conta.comprar(quantidade);
    }

    public void vender(Conta conta, double quantidade) {
        conta.vender(quantidade);
    }
    
}







