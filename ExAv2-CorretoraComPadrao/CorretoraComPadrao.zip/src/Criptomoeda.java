interface Criptomoeda {
    void comprar(double quantidade);
    void vender(double quantidade);
}